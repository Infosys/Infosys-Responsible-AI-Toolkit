from typing import Optional, List, Tuple, Set


from presidio_analyzer.predefined_recognizers.spacy_recognizer import SpacyRecognizer
from presidio_analyzer import RecognizerResult, AnalysisExplanation


class CustomPersonRecognizer(SpacyRecognizer):
    """
    A custom SpacyRecognizer that ONLY detects PERSON with a lower score
    and specific context words.
    """

    ENTITIES = [
        "PERSON",
    ]

    CHECK_LABEL_GROUPS = [
        ({"PERSON", "PER"}, {"PERSON", "PER"}),
    ]

    def __init__(
        self,
        supported_language: str = "en",
        supported_entities: Optional[List[str]] = None,
        ner_strength: float = 0.6,  # Your custom default score
        check_label_groups: Optional[List[Tuple[Set, Set]]] = None,
        context: Optional[List[str]] = [
            "mr", "mrs", "ms", "dr", "prof", "name", "user",
            "client", "employee",  "patient", "signature", "my name is","My name is","I am","i am","Signed by",
            "my Name is","name is"
        ],
    ):
        self.check_label_groups = (
            check_label_groups if check_label_groups else self.CHECK_LABEL_GROUPS
        )
        
        super().__init__(
            supported_entities=supported_entities if supported_entities else self.ENTITIES,
            supported_language=supported_language,
            ner_strength=ner_strength,
            context=context,
        )

    # --- NO CHANGES NEEDED TO THE METHODS BELOW ---
    def build_spacy_explanation(
        self, original_score: float, explanation: str
    ) -> AnalysisExplanation:
        explanation = AnalysisExplanation(
            recognizer=self.__class__.__name__,
            original_score=original_score,
            textual_explanation=explanation,
        )
        return explanation

    def analyze(self, text, entities, nlp_artifacts=None):
        results = []
        if not nlp_artifacts:
            return results

        ner_entities = nlp_artifacts.entities
        for entity in entities:
            if entity not in self.supported_entities:
                continue
            for ent in ner_entities:
                if not self.__check_label(entity, ent.label_, self.check_label_groups):
                    continue
                
                textual_explanation = self.DEFAULT_EXPLANATION.format(ent.label_)
                explanation = self.build_spacy_explanation(
                    self.ner_strength, textual_explanation
                )
                spacy_result = RecognizerResult(
                    entity_type=entity,
                    start=ent.start_char,
                    end=ent.end_char,
                    score=self.ner_strength,
                    analysis_explanation=explanation,
                    recognition_metadata={
                        RecognizerResult.RECOGNIZER_NAME_KEY: self.name,
                        RecognizerResult.RECOGNIZER_IDENTIFIER_KEY: self.id,
                    },
                )
                results.append(spacy_result)
        return results

    @staticmethod
    def __check_label(
        entity: str, label: str, check_label_groups: List[Tuple[Set, Set]]
    ) -> bool:
        return any(
            [entity in egrp and label in lgrp for egrp, lgrp in check_label_groups]
        )
