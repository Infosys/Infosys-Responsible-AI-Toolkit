import contextvars
from presidio_analyzer import Pattern, PatternRecognizer, AnalyzerEngine, RecognizerRegistry, predefined_recognizers
from presidio_anonymizer import AnonymizerEngine
from privacy.config.logger import CustomLogger
from presidio_image_redactor import ImageRedactorEngine, ImageAnalyzerEngine, ImagePiiVerifyEngine       
from presidio_image_redactor import DicomImageRedactorEngine

log = CustomLogger()


from presidio_analyzer.nlp_engine import SpacyNlpEngine
from presidio_analyzer.predefined_recognizers.spacy_recognizer import SpacyRecognizer
import spacy
from privacy.util.lemma_context_aware_enhancer1 import LemmaContextAwareEnhancer
from privacy.util.custom_recognizers import CustomPersonRecognizer
 
error_dict={}
admin_par={}
session_dict = contextvars.ContextVar('session_dict', default={})
 
def update_session_dict(key, value):
    session_dict.get()[key] = value
 
def get_session_dict():
    return session_dict.get()
 
class AttributeDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__
 

 
registry = RecognizerRegistry()
anonymizer = AnonymizerEngine()
 
# 1. Load all the default recognizers
registry = RecognizerRegistry()
anonymizer = AnonymizerEngine()

# 1. Load all the default recognizers
registry.load_predefined_recognizers()

# 2. Remove the original all-in-one recognizer so we can replace it with specialists
try:
    registry.remove_recognizer("SpacyRecognizer", language="en")
    log.info("Removed default SpacyRecognizer to replace with custom versions.")
except ValueError:
    log.warning("Default SpacyRecognizer not found in registry, continuing.")


# 3. Re-add the original SpacyRecognizer, but ONLY for the entities that work well.
#    We are telling it to IGNORE "PERSON".
default_spacy_recognizer = SpacyRecognizer(
    supported_entities=["LOCATION", "ORGANIZATION", "DATE_TIME", "NRP"]
)
registry.add_recognizer(default_spacy_recognizer)
log.info("Added original SpacyRecognizer for non-PERSON entities.")


# 4. Create your specialist recognizer ONLY for PERSON, with its own score and context.
custom_person_recognizer = CustomPersonRecognizer()
registry.add_recognizer(custom_person_recognizer)
log.info("Added CustomPersonRecognizer with special rules for PERSON.")


lemma_context_aware_enhancer = LemmaContextAwareEnhancer()
 
"""Default NLP , Less Accuracy less latency"""
analyzer_l = AnalyzerEngine(registry=registry, context_aware_enhancer=lemma_context_aware_enhancer)
print(f"DEBUG: Available recognizers: {registry.get_supported_entities()}")
 
 
"""En_core_web_trf NLP , slightly better Accuracy little High latency"""
class LoadedSpacyNlpEngine(SpacyNlpEngine):
    def __init__(self, loaded_spacy_model):
        super().__init__()
        self.nlp = {"en": loaded_spacy_model}
 
def selectNlp(nlpName):
    if nlpName == "basic":
        print("basic")
        return analyzer_l
    else:
        return analyzer_l