from privacy.mappers.mappers import *
import os
import json
from importlib import resources
from typing import List
from privacy.config.logger import CustomLogger
log = CustomLogger()
from dotenv import load_dotenv
from privacy.config.logger import request_id_var
load_dotenv()
from faker import Faker
fake = Faker()
from privacy.util.special_recognizers.DataListRecognizer import DataListRecognizer
from privacy.service.__init__ import *
from privacy.service.api_req import ApiCall
from privacy.service.loadRecognizer import LoadRecognizer
import time ## Added for profiling
from privacy.util.special_recognizers.fakeData import FakeDataGenerate


ENTITY_CANONICAL_MAP = {
    "IN_AADHAAR": "INDIA_AADHAR",
    "AADHAR_NUMBER": "INDIA_AADHAR",
    "INDIA_AADHAR": "INDIA_AADHAR",
 
    "IN_PAN": "INDIA_PAN",
    "PAN_Number": "INDIA_PAN",
    "INDIA_PAN": "INDIA_PAN",
 
    "US_SSN": "USA_SSN",
 
    "USA_SSN": "USA_SSN",
 
    "DATE_TIME": "DATE",
    "DATE": "DATE",
 
    # Add any additional mappings as needed below
}
def normalize_entities(entity_list):
    normalized = set()
    for ent in entity_list:
        # Find matching key in ENTITY_CANONICAL_MAP ignoring case
        canonical = None
        for key in ENTITY_CANONICAL_MAP:
            if key.lower() == ent.lower():
                canonical = ENTITY_CANONICAL_MAP[key]
                break
        # If no mapping found, keep original entity
        if canonical is None:
            canonical = ent
        normalized.add(canonical)
    return list(normalized)

## Cache for basic recognizers to avoid repeated file loading.
## NOTE: For a production application, this loading logic should be moved
## to your application's startup sequence (e.g., in your app.py or main.py).
_basic_recognizers_loaded = False




class TextPrivacy:

    def analyze(payload: PIIAnalyzeRequest) -> PIIAnalyzeResponse:
        start_time = time.time()
        error_dict[request_id_var.get()] = []
        log.debug("Entering in analyze function")
        log.debug(f"Payload: {payload}")
        piiEntitiesToBeRedacted = payload.piiEntitiesToBeRedacted
        try:
            exclusionList = payload.exclusionList or []
            privacy_obj = TextPrivacy()
            log.debug(f"portfolio: {payload.portfolio}, exclusionList: {exclusionList}")

            block_start = time.time()
            if payload.portfolio is None:
                log.debug("No portfolio mode: calling textAnalyze for base recognizers")
                results = privacy_obj.textAnalyze(
                    text=payload.inputText,
                    piiEntitiesToBeRedacted=piiEntitiesToBeRedacted,
                    exclusion=exclusionList,
                    scoreThreshold=payload.scoreThreshold,
                )
            else:
                log.debug("Portfolio mode: calling textAnalyze with accName")
                results = privacy_obj.textAnalyze(
                    text=payload.inputText,
                    accName=payload,
                    exclusion=exclusionList,
                )
            log.info(f"textAnalyze call time: {time.time() - block_start:.4f} seconds")

            block_start = time.time()
            if results in [None, 404, 482]:
                log.warning(f"Analysis returned code: {results}")
                return results

            results = sorted(results, key=lambda i: i.start)
            list_PIIEntity = []
            for result in results:
                log.debug(f"Adding detected PII: {result.entity_type} at {result.start}-{result.end}")
                obj_PIIEntity = PIIEntity(
                    type=result.entity_type,
                    beginOffset=result.start,
                    endOffset=result.end,
                    score=result.score,
                    responseText=payload.inputText[result.start:result.end],
                )
                list_PIIEntity.append(obj_PIIEntity)
            log.info(f"Entity packaging time: {time.time() - block_start:.4f} seconds")

            log.info(f"Total PII entities found: {len(list_PIIEntity)}")
            log.info(f"Total analyze() time: {time.time() - start_time:.4f} seconds")
            return PIIAnalyzeResponse(PIIEntities=list_PIIEntity)

        except Exception as e:
            log.error(str(e))
            log.error("Line No:" + str(e.__traceback__.tb_lineno))
            error_dict[request_id_var.get()].append({
                "UUID": request_id_var.get(),
                "function": "textAnalyzeMainFunction",
                "msg": str(e.__class__.__name__),
                "description": str(e) + " Line No:" + str(e.__traceback__.tb_lineno),
            })
            raise

    

    def textAnalyze(
        self,
        text: str,
        accName: any = None,
        exclusion: any = None,
        piiEntitiesToBeRedacted: any = None,
        scoreThreshold: float = 0,
    ):
        fn_start = time.time()
        result = []
        analyzer = selectNlp("basic")
        ad_hoc_recognizers = []
        log.info(f"Starting textAnalyze, accName: {accName}")

        try:
            block_start = time.time()
            if accName is None:
                global _basic_recognizers_loaded
                if not _basic_recognizers_loaded:
                    log.info("Loading basic recognizers for the first time...")
                    try:
                        load_start = time.time()
                        with resources.open_text('privacy.service', 'recoglist.json') as f:
                            file_contents = f.read()
                        initial_payload = AttributeDict({
                            'contents_bytes': file_contents.encode("utf-8")
                        })
                        LoadRecognizer.set_recognizer(initial_payload)
                        _basic_recognizers_loaded = True
                        log.info(f"Basic recognizers loaded in {time.time() - load_start:.4f} seconds.")
                    except Exception as e:
                        log.error(f"FATAL: Could not load basic recognizers from recoglist.json: {e}", exc_info=True)

                log.info(f"Calling analyzer.analyze with global recognizers. Entities: {piiEntitiesToBeRedacted}")
                log.info("----------------------------------------------------")
                log.info(">> Preparing to call analyzer.analyze (base mode)")
                log.info(f">> Text length: {len(text)} characters")
                log.info(f">> Entities to find: {'ALL (None specified)' if not piiEntitiesToBeRedacted else piiEntitiesToBeRedacted}")
                log.info(f">> Exclusion list size: {len(exclusion) if exclusion else 0}")
                log.info(f">> Score threshold: {scoreThreshold}")
                log.info(f">> Return decision process: True  <-- WARNING: This is very slow!")
                log.info("----------------------------------------------------")
                analyze_start = time.time()
                result = analyzer.analyze(
                    text=text,
                    language="en",
                    entities=piiEntitiesToBeRedacted,
                    allow_list=exclusion,
                    return_decision_process=False,
                    score_threshold=scoreThreshold
                )
                log.info(f"analyze() call time (base mode): {time.time() - analyze_start:.4f} seconds")

            else:
                start_time = time.time()
                response_value = ApiCall.request(accName)
                log.info(f"ApiCall.request took {time.time() - start_time:.4f} seconds.")

                if response_value in [None, 404]:
                    log.error(f"ApiCall.request failed or returned {response_value}")
                    return response_value

                entityType, datalist, preEntity = response_value
                log.info(f"Loaded dynamic recognizers: types={entityType}, datas={datalist}, preEntities={preEntity}")

                recog_start = time.time()
                for d in range(len(datalist)):
                    record = AttributeDict(ApiCall.getRecord(entityType[d]))
                    if record.RecogType == "Data":
                        log.debug(f"Adding Data recognizer for {entityType[d]}")
                        dataRecog = DataListRecognizer(terms=datalist[d], entitie=[entityType[d]])
                        ad_hoc_recognizers.append(dataRecog)
                        update_session_dict(entityType[d], datalist[d])
                    elif record.RecogType == "Pattern" and record.isPreDefined == "No":
                        log.debug(f"Adding Pattern recognizer for {entityType[d]}")
                        pattern = "|".join(datalist[d])
                        contextObj = record.Context.split(",")
                        patternObj = Pattern(name=entityType[d], regex=pattern, score=record.Score)
                        patternRecog = PatternRecognizer(
                            supported_entity=entityType[d],
                            patterns=[patternObj],
                            context=contextObj,
                        )
                        ad_hoc_recognizers.append(patternRecog)
                log.info(f"Dynamic recognizer setup time: {time.time() - recog_start:.4f} seconds")
                log.info("----------------------------------------------------")
                log.info(">> Preparing to call analyzer.analyze (portfolio mode)")
                log.info(f">> Text length: {len(text)} characters")
                log.info(f">> Entities to find: {entityType + preEntity}")
                log.info(f">> Ad-hoc recognizers: {len(ad_hoc_recognizers)} added")
                log.info(f">> Score threshold: {admin_par[request_id_var.get()]['scoreTreshold']}")
                log.info(f">> Return decision process: True  <-- WARNING: This is very slow!")
                log.info("----------------------------------------------------")

                analyze_start = time.time()
                results = analyzer.analyze(
                    text=text,
                    language="en",
                    entities=entityType + preEntity,
                    allow_list=exclusion,
                    score_threshold=admin_par[request_id_var.get()]["scoreTreshold"],
                    return_decision_process=True,
                    ad_hoc_recognizers=ad_hoc_recognizers,
                )
                log.info(f"analyze() call time (portfolio mode): {time.time() - analyze_start:.4f} seconds")
                result.extend(results)
                

            
            return result

        except Exception as e:
            log.error(str(e))
            log.error("Line No:" + str(e.__traceback__.tb_lineno))
            error_dict[request_id_var.get()].append({
                "UUID": request_id_var.get(),
                "function": "textAnalyzeFunction",
                "msg": str(e.__class__.__name__),
                "description": str(e) + " Line No:" + str(e.__traceback__.tb_lineno),
            })
            raise
    def anonymize(payload: PIIAnonymizeRequest):
        """
        Analyzes and anonymizes text based on the provided payload.
        """
        start_time = time.time()
        log.info("Starting anonymize function.")

        try:
            # Step 1: Analyze the text to find PII entities
            analyze_start = time.time()
            privacy_obj = TextPrivacy()

            # Consolidate logic for text analysis
            if payload.portfolio is None:
                log.info("Anonymizing in 'no portfolio' mode.")
                results = privacy_obj.textAnalyze(
                    text=payload.inputText,
                    exclusion=payload.exclusionList or [],
                    piiEntitiesToBeRedacted=normalize_entities(payload.piiEntitiesToBeRedacted) if payload.piiEntitiesToBeRedacted else None,
                    scoreThreshold=payload.scoreThreshold,
                )
            else:
                log.info("Anonymizing in 'portfolio' mode.")
                results = privacy_obj.textAnalyze(
                    text=payload.inputText,
                    accName=payload,
                    exclusion=payload.exclusionList or [],
                    piiEntitiesToBeRedacted=normalize_entities(payload.piiEntitiesToBeRedacted) if payload.piiEntitiesToBeRedacted else None,
                )
            log.info(f"Text analysis completed in {time.time() - analyze_start:.4f} seconds.")

            # Handle analysis errors
            if not results or results in [404, 482]:
                log.warning(f"Analysis returned a non-success code: {results}. Returning original text.")
                return PIIAnonymizeResponse(anonymizedText=payload.inputText)

            # Step 2: Prepare the operators for anonymization
            operators = {}
            # Apply fake data generation if enabled
            if payload.fakeData:
                log.debug("Generating fake data for PII entities.")
                fake_operators = FakeDataGenerate.fakeDataGeneration(results, payload.inputText)
                operators.update(fake_operators)

            # Apply encryption (hashing) for specific entities if configured
            if payload.portfolio and "encryptionList" in admin_par.get(request_id_var.get(), {}):
                encryption_list = admin_par[request_id_var.get()]["encryptionList"]
                log.debug(f"Applying encryption for entities: {encryption_list}")
                for entity in encryption_list:
                    operators[entity] = OperatorConfig("hash", {"hash-type": "md5"})

            # Step 3: Perform the anonymization using the prepared operators
            anonymize_start = time.time()
            anonymized_result = anonymizer.anonymize(
                text=payload.inputText,
                operators=operators,
                analyzer_results=results,
            )
            log.info(f"Text anonymization completed in {time.time() - anonymize_start:.4f} seconds.")

            # Step 4: Return the final response
            response = PIIAnonymizeResponse(anonymizedText=anonymized_result.text)
            log.info(f"Total anonymize function execution time: {time.time() - start_time:.4f} seconds.")
            return response

        except Exception as e:
            log.error(f"Error during anonymization: {str(e)}", exc_info=True)
            # Detailed error logging for debugging
            error_dict[request_id_var.get()].append({
                "UUID": request_id_var.get(),
                "function": "anonymize",
                "msg": str(e.__class__.__name__),
                "description": f"{e} Line No: {e.__traceback__.tb_lineno}",
            })
            raise
