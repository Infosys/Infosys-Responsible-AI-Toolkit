import json
import threading
import re
import time
import uuid
import requests
import tracemalloc
from fastapi import Depends, Query, APIRouter, HTTPException, FastAPI, Response
from flask_cors import cross_origin
from privacy.mappers.mappers import *
from privacy.exception.exception import PrivacyException
from privacy.config.logger import CustomLogger
from fastapi import FastAPI
from datetime import date
import concurrent.futures
from privacy.service.api_req import *
from privacy.service.__init__ import *
from privacy.service.textPrivacy import TextPrivacy

router = APIRouter()
log = CustomLogger()
app = FastAPI()

fileRouter = APIRouter()

today = date.today()
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()
import os
from privacy.config.logger import request_id_var
from fastapi import APIRouter, HTTPException, Depends
from privacy.util.auth.auth_client_id import get_auth_client_id
from privacy.util.auth.auth_jwt import get_auth_jwt
from privacy.util.auth.auth_none import get_auth_none

now = datetime.now()

sslv = {"False": False, "True": True, "None": True}
 
magMap = {"True": True, "False": False, "true": True, "false": False}
tel_Falg = os.getenv("TELE_FLAG")
tel_Falg = magMap[tel_Falg]

privacytelemetryurl = os.getenv("PRIVACY_TELEMETRY_URL")
privacyerrorteleurl = os.getenv("PRIVACY_ERROR_URL")


class NoAccountException(Exception):
    pass


class NoAdminConnException(Exception):
    pass


class NoMatchingRecognizer(Exception):
    pass



## FUNCTION FOR FAIL_SAFE TELEMETRY
def send_telemetry_request(privacy_telemetry_request):
    id = uuid.uuid4().hex
    request_id_var.set("telemetry")

    try:

        log.debug("teleReq=" + json.dumps(privacy_telemetry_request, indent=4))
        
        response = requests.post(privacytelemetryurl, json=privacy_telemetry_request,verify=sslv[os.getenv("VERIFY_SSL","None")])
 
        response.raise_for_status()
        response_data = response.json()
        log.debug("tele data response: "+ str(response))
 
    except Exception as e:
        log.error(str(e))
        # ExceptionDb.create({"UUID":request_id_var.get(),"function":"send_telemetry_requestFunction","msg":str(e),"description":str(e)+"Line No:"+str(e.__traceback__.tb_lineno)})
        raise HTTPException(
            status_code=500,    
            detail="Please check with administration!!",
            headers={"X-Error": "Please check with administration!!"})
        
        
class Telemetry:
    def error_telemetry_request(errobj, id):
        request_id_var.set(id)

        try:
 
            log.debug("teleReq="+str(errobj))
            log.debug("teleReq="+str(errobj['error']))  # Convert list to string before concatenating
            errorRequest = errobj['error'][0]
 
            if(tel_Falg):
                response = requests.post(privacyerrorteleurl, json=errorRequest, verify=sslv[os.getenv("VERIFY_SSL", "None")])
 
                response.raise_for_status()
                response_data = response.json()
                log.debug("tele error response: "+ str(response))
 
        except Exception as e:
            log.error(str(e))
            # ExceptionDb.create({"UUID":request_id_var.get(),"function":"send_telemetry_requestFunction","msg":str(e),"description":str(e)+"Line No:"+str(e.__traceback__.tb_lineno)})
            raise HTTPException(
                status_code=500,    
                detail="Please check with administration!!",
                headers={"X-Error": "Please check with administration!!"})
# Authentication 

auth_type = os.environ.get("AUTH_TYPE")

if auth_type == "azure":
    auth = get_auth_client_id()
elif auth_type == "jwt":
    auth = get_auth_jwt()

elif auth_type == 'none':
    auth = get_auth_none()
else:
    raise HTTPException(status_code=500, detail="Invalid authentication type configured")
    

router = APIRouter()
@router.post('/privacy/text/analyze', response_model= PIIAnalyzeResponse)
# @profile
def analyze(payload: PIIAnalyzeRequest, auth= Depends(auth)):

    # gc.collect()
    id = uuid.uuid4().hex
    request_id_var.set(id)
    log.info("Entered into analyze routing method" )

    try:
        log.debug("request payload: "+ str(payload))

        if payload.inputText:
            # payload.inputText = payload.inputText.lower()
            # log.debug("Converted inputText to lowercase: " + payload.inputText)
             # Convert to lowercase
            payload.inputText = payload.inputText.lower()
            # Remove extra spaces and newline characters
            payload.inputText = re.sub(r'\s+', ' ', payload.inputText)
            # Remove special characters (keep only alphanumeric and spaces)
            #payload.inputText = re.sub(r'[^\w\s]', '', payload.inputText)

            log.debug("Preprocessed inputText: " + payload.inputText)


        # raise Exception("This is a test exception")  # Add this line to raise an exception
        startTime = time.time()
        log.debug("Entered into analyze function")
        tracemalloc.start()
        # raise Exception()
        response = TextPrivacy.analyze(payload)
        ApiCall.delAdminList()
        tracemalloc.stop()
        log.debug("Returned from analyze function")
        endTime = time.time()
        totalTime = endTime - startTime
          
        log.info("Total Time taken "+str(totalTime))
        if(response==482):
            raise NoMatchingRecognizer
        if(response==None):
 
            # return "Portfolio/Account Is Incorrect"
            raise NoAccountException
 
        if(response==404):
            raise NoAdminConnException
        
    
        log.debug("response : "+ str(response))
        log.info("exit create from analyze routing method")
        # telFlagData = TelemetryFlag.findall({"Module":"Privacy"})[0]
        # tel_Falg = telFlagData["TelemetryFlag"]
        log.debug("TelFlag==="+ str(tel_Falg))
        # TelemetryDb.create({"UUID":id,"tenant":"privacy","apiName":analyze.__name__,"portfolio":payload.portfolio,"accountName":payload.account,"exclusion_list":payload.exclusionList,"entityrecognised":"Text"})
        if(tel_Falg == True):
            responseList = list(map(lambda obj: obj.__dict__, response.PIIEntities))
            requestList = payload.__dict__
            requestObj = {
                "portfolio_name": payload.portfolio if payload.portfolio is not None else "None",
                "account_name": payload.account if payload.account is not None else "None",
                "inputText": requestList["inputText"],
                "exclusion_list": requestList["exclusionList"].split(',') if requestList["exclusionList"] is not None else [],
            }
            # lotNumber = 0  # Initialize lotNumber with a default value
            # if payload.lotNumber is not None:
            #     lotNumber = payload.lotNumber
            
            telemetryPayload = {
                "uniqueid": id,
                "tenant": "privacy",
                "apiname": analyze.__name__,           
                "user": payload.user if payload.user is not None else "None",
                "date":now.isoformat(),
                "lotNumber": payload.lotNumber if payload.lotNumber is not None else "None",
                # "exclusionList": payload.exclusionList,
                "request": requestObj,
                "response": responseList
            }
            
            with concurrent.futures.ThreadPoolExecutor() as executor:
                executor.submit(send_telemetry_request, telemetryPayload)
            log.info("******TELEMETRY REQUEST COMPLETED********")
        
        
        return response
    except PrivacyException as cie:
        log.debug("Exception for analyze")
        log.error(cie.__dict__)

        er=[{"tenetName":"Privacy","errorCode":"textAnalyzeRouter","errorMessage":str(e)+"Line No:"+str(e.__traceback__.tb_lineno),"apiEndPoint":"/privacy/text/analyze", "errorRequestMethod":"POST"}]
        er.extend(error_dict[request_id_var.get()] if request_id_var.get() in error_dict else [])
        logobj = {"uniqueid":id,"error":er}
        # 
        if len(er)!=0:
            thread = threading.Thread(target=Telemetry.error_telemetry_request, args=(logobj,id))
            thread.start()
            if request_id_var.get() in error_dict:
                del error_dict[id] 
        # ExceptionDb.create({"UUID":id,"function":"textAnalyzeRouter","msg":cie.__dict__,"description":cie.__dict__})

        log.error(cie, exc_info=True)
        log.info("exit create from analyze routing method")
        raise HTTPException(**cie.__dict__)
    except NoAccountException:
        raise HTTPException(
            status_code=430,
            detail="Portfolio/Account Is Incorrect",
            headers={"X-Error": "There goes my error"},
        )
    except NoAdminConnException:
        raise HTTPException(
            status_code=435,
            detail=" Accounts and Portfolio not available with the Subscription!!",
            headers={"X-Error": "Admin Connection is not established,"},
        )
    except NoMatchingRecognizer:
        raise HTTPException(
            status_code=482,
            detail=" No matching recognizers were found to serve the request.",
            headers={"X-Error": "Check Recognizer"},
        )
    except Exception as e:
        log.error(str(e))
 
        er=[{"tenetName":"Privacy","errorCode":"textAnalyzeRouter","errorMessage":str(e)+"Line No:"+str(e.__traceback__.tb_lineno),"apiEndPoint":"/privacy/text/analyze", "errorRequestMethod":"POST"}]
        er.extend(error_dict[request_id_var.get()] if request_id_var.get() in error_dict else [])
        logobj = {"uniqueid":id,"error":er}
        # 
        if len(er)!=0:
            thread = threading.Thread(target=Telemetry.error_telemetry_request, args=(logobj,id))
            thread.start()
            if request_id_var.get() in error_dict:
                del error_dict[id] 
        # ExceptionDb.create({"UUID":request_id_var.get(),"function":"textAnalyzeRouter","msg":str(e),"description":str(e)+"Line No:"+str(e.__traceback__.tb_lineno)})
        raise HTTPException(
            status_code=500,
            detail="Please check with administration!!",
            headers={"X-Error": "Please check with administration!!"})
@router.post('/privacy/text/anonymize', response_model= PIIAnonymizeResponse)
def anonymize(payload: PIIAnonymizeRequest,auth= Depends(auth)):
    
    id = uuid.uuid4().hex
    request_id_var.set(id)
    
    log.info("Entered create into anonymize routing method")
    try:
        # log.info("Entered create usecase routing method" )
        log.debug("request payload: "+ str(payload))

        if payload.inputText:
            payload.inputText = payload.inputText.lower()
            log.debug("Converted inputText to lowercase: " + payload.inputText)

        startTime = time.time()
        log.debug("Entered into anonymize function")
        response = TextPrivacy.anonymize(payload)
 
        ApiCall.delAdminList()
        log.debug("Returned from anonymize function")
        endTime = time.time()
        totalTime = endTime - startTime
        log.info("Total Time taken "+str(totalTime))
        # if(response!=482 or response!=None or response!=404):
        #     log.debug("response : "+ str(response))
        #     pass
        if(response==482):

            raise NoMatchingRecognizer
        if(response==None):
            raise NoAccountException
        if(response==404):
            raise NoAdminConnException
        log.debug("response : "+ str(response))
        log.info("exit create from anonymize routing method")
        if(tel_Falg == True):
            log.debug("Inside Telemetry Flag")
            requestList = payload.__dict__
            requestObj = {
               "portfolio_name": payload.portfolio if payload.portfolio is not None else "None",
                "account_name": payload.account if payload.account is not None else "None",
                "inputText": requestList["inputText"],
                "exclusion_list": requestList["exclusionList"].split(',') if requestList["exclusionList"] is not None else [],
            }
            responseObj = {
                "type": "None",
                "beginOffset": 0,
                "endOffset": 0,
                "score": 0,
                "responseText": response.anonymizedText
            }
            telemetryPayload = {
                "uniqueid": id,
                "tenant": "privacy",
                "apiname": anonymize.__name__,
                "user": payload.user if payload.user is not None else "None",
                "date":now.isoformat(),
                "lotNumber": payload.lotNumber if payload.lotNumber is not None else "None",
                # "exclusionList": payload.exclusionList,
                "request": requestObj,
                "response": [responseObj]
            }
            # Trigger the API call asynchronously using a separate thread
           
            with concurrent.futures.ThreadPoolExecutor() as executor:
                executor.submit(send_telemetry_request, telemetryPayload)
            log.info("******TELEMETRY REQUEST COMPLETED********")
        return response
    except PrivacyException as cie:
        log.error("Exception for anonymize")
        log.error(cie.__dict__)
        er=[{"tenetName":"Privacy","errorCode":"textAnonimyzeRouter","errorMessage":str(e)+"Line No:"+str(e.__traceback__.tb_lineno),"apiEndPoint":"/privacy/text/annonymize", "errorRequestMethod":"POST"}]
        # er=[{"UUID":id,"function":"textAnonimyzeRouter","msg":cie.__dict__,"description":cie.__dict__}]
        er.extend(error_dict[request_id_var.get()] if request_id_var.get() in error_dict else [])
        logobj = {"uniqueid":id,"error":er}
        # 
        if len(er)!=0:
            thread = threading.Thread(target=Telemetry.error_telemetry_request, args=(logobj,id))
            thread.start()
            if request_id_var.get() in error_dict:
                del error_dict[id] 
        log.error(cie, exc_info=True)
        log.info("exit create from anonymize routing method")
        raise HTTPException(**cie.__dict__)
    except NoAccountException:
        raise HTTPException(
            status_code=430,
            detail="Portfolio/Account Is Incorrect",
            headers={"X-Error": "There goes my error"},
        )
    except NoAdminConnException:
        raise HTTPException(
            status_code=435,
            detail=" Accounts and Portfolio not available with the Subscription!!",
            headers={"X-Error": "Admin Connection is not established,"},
        )
    except NoMatchingRecognizer:
        raise HTTPException(
            status_code=482,
            detail=" No matching recognizers were found to serve the request.",
            headers={"X-Error": "Check Recognizer"},
        )
    except Exception as e:
        log.error(str(e))
        # ExceptionDb.create({"UUID":request_id_var.get(),"function":"textAnonimyzeRouter","msg":str(e),"description":str(e)+"Line No:"+str(e.__traceback__.tb_lineno)})
        er=[{"tenetName":"Privacy","errorCode":"textAnonimyzeRouter","errorMessage":str(e)+"Line No:"+str(e.__traceback__.tb_lineno),"apiEndPoint":"/privacy/text/annonymize", "errorRequestMethod":"POST"}]
        er.extend(error_dict[request_id_var.get()] if request_id_var.get() in error_dict else [])
        logobj = {"uniqueid":id,"error":er}
        # 
        if len(er)!=0:
            thread = threading.Thread(target=Telemetry.error_telemetry_request, args=(logobj,id))
            thread.start()
            if request_id_var.get() in error_dict:
                del error_dict[id] 
        raise HTTPException(
            status_code=500,
            detail="Please check with administration!!",
            headers={"X-Error": "Please check with administration!!"})
